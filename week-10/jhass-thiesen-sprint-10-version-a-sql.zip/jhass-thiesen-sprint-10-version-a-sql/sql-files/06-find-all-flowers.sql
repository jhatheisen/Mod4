-- Your code here
SELECT DISTINCT variety, color, stem_length FROM flowers
ORDER BY variety, color, stem_length;
