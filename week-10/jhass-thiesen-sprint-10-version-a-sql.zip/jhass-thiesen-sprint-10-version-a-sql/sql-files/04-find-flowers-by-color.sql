-- Your code here
SELECT variety, color, stem_length FROM flowers
WHERE color = 'pink' OR color = 'purple'
ORDER BY variety, color, stem_length;
