-- Your code here
DELETE FROM flowers
WHERE id IN (
  SELECT flower_id FROM bouquet
  WHERE name = 'Get Well Soon'
);
