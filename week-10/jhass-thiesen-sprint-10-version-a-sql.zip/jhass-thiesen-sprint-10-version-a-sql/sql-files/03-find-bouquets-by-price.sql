-- Your code here
SELECT DISTINCT name, price FROM bouquet
WHERE price BETWEEN 30.45 AND 40.36
ORDER BY name ASC;
