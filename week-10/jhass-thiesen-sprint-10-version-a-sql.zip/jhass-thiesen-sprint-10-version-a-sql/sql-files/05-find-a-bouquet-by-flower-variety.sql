-- Your code here
SELECT bouquet.name, bouquet.price FROM bouquet
JOIN flowers ON (bouquet.flower_id = flowers.id)
WHERE flowers.variety = 'Carnation'
ORDER BY name 
LIMIT 1;
