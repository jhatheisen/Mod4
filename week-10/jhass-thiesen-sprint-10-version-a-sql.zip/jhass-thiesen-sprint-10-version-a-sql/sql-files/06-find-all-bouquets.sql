-- Your code here
SELECT DISTINCT name FROM bouquet
ORDER BY name ASC;
