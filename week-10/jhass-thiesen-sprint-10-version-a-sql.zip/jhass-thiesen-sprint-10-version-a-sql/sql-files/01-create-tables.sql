-- This ensures that SQLite enforces FOREIGN KEY constraints
PRAGMA foreign_keys = 1;

-- Your code here

CREATE TABLE flowers (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  color VARCHAR(40),
  stem_length VARCHAR(40),
  variety VARCHAR(40)
);

CREATE TABLE bouquet (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  bouquet_id INTEGER,
  name VARCHAR(40),
  price NUMERIC(7, 2),
  flower_id INTEGER,
  FOREIGN KEY (flower_id) REFERENCES flowers(id) ON DELETE CASCADE
);
