-- Your code here
INSERT INTO flowers (color, stem_length, variety)
VALUES
  ('yellow', 'short', 'Carnation'),
  ('white', 'short', 'Carnation'),
  ('white', 'short', 'Lily'),
  ('yellow', 'medium', 'Solidago'),
  ('yellow', 'short', 'Daisy');

INSERT INTO bouquet (bouquet_id, name, price, flower_id)
VALUES
  (1,'Get Well Soon', 59.99, 1),
  (1,'Get Well Soon', 59.99, 2),
  (1,'Get Well Soon', 59.99, 3),
  (1,'Get Well Soon', 59.99, 4),
  (1,'Get Well Soon', 59.99, 5);

INSERT INTO flowers (color, stem_length, variety)
VALUES
  ('pink', 'long', 'Carnation'),
  ('purple', 'long', 'Carnation'),
  (null, 'long', 'Baby''s Breath');

INSERT INTO bouquet (bouquet_id, name, price, flower_id)
VALUES
  (2, 'Mother''s Day', 39.99, 6),
  (2, 'Mother''s Day', 39.99, 7),
  (2, 'Mother''s Day', 39.99, 8);
